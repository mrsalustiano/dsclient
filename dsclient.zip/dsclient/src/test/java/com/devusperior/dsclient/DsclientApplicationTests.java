package com.devusperior.dsclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
